<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('warehouse_loadings', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('warehouse_management_id')->default(0);
            $table->bigInteger('sku')->default(0);
            $table->bigInteger('loading_qty')->default(0);
            $table->bigInteger('unloading_qty')->default(0);
            $table->bigInteger('sale_qty')->default(0);
            $table->bigInteger('price')->default(0);
            $table->bigInteger('total_sale_qty')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('warehouse_loadings');
    }
};
