<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('s_k_u_s', function (Blueprint $table) {
            $table->id();
            $table->string('sku')->unique();
            $table->string('label')->nullable();
            $table->decimal('price', 10, 2);
            $table->json('stock')->default(json_encode([]));
            $table->bigInteger('max_sale_bundle')->default(1);
            
            $table->enum('unit', ['KG', 'Count'])->default('KG');
            $table->integer('packet_size')->default(1);
            $table->json('cities')->nullable();
            $table->string('image')->default('default.png');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('s_k_u_s');
    }
};
