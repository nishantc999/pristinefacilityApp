<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('warehouse_management', function (Blueprint $table) {
            $table->id();

              $table->bigInteger('vehicle_id')->default(0);
              $table->bigInteger('city_id')->default(0);
              $table->bigInteger('warehouse_id')->default(0);
              $table->string('location', 500)->nullable();
              $table->string('landmark')->nullable();
              $table->boolean('location_status')->default(0);
              $table->string('fe_id')->nullable();

              $table->boolean('fe_status')->default(0);

              $table->boolean('loading_status')->default(0);

              $table->boolean('unloading_status')->default(0);
              $table->float('cash_collected', 8, 2)->default(0);
              $table->float('upi_collected', 8, 2)->default(0);
              $table->float('total_collected', 8, 2)->default(0);
              $table->boolean('collected_status')->default(0);
              $table->string('reason_for_difference')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('warehouse_management');
    }
};
