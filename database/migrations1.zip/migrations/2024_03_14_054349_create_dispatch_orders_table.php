<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('dispatch_orders', function (Blueprint $table) {
            $table->id();
            $table->string('pickup_date')->nullable();
            $table->string('release_order_id')->nullable();
            $table->string('warehouse_id')->nullable();
            $table->json('product')->default(json_encode([]));
           $table->bigInteger('user_id')->default(0);
           $table->json('quantity')->default(json_encode([]));
           $table->string('weighment_number')->nullable();
           $table->string('warehouse_contact')->nullable();
           $table->string('vehicle_number')->nullable();
           $table->text('warehouse_adddress')->nullable();
           $table->string('warehouse_map')->nullable();
           $table->string('weighment_slip')->nullable();
           $table->string('vehicle_photo')->nullable();
           $table->boolean('master_upload_status')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('dispatch_orders');
    }
};
